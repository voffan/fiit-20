﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication8
{
    class Sportsman:Person
    {
        public int BirthDay { get; set; }
        public int BirthPlace { get; set; }
        public int PhoneNumber { get; set; }
        public int Score { get; set; }
    }
}
